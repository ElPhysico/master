#ifndef FPT
#define FPT

#include "system.hpp"
#include "walker.hpp"
#include "functions.hpp"
//#include <utility>


/* Functions */
void MFPT(string &file, double p);

#endif
