#ifndef IMG
#define IMG

#include "system.hpp"
#include "walker.hpp"
#include <gd.h>

using namespace std;


/* Variables */


/* Functions */
void initPNG(string file);
void updatePNG();
void drawPNG();

#endif
