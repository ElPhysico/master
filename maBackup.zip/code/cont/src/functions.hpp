#ifndef FUNCTIONS
#define FUNCTIONS

#include "system.hpp"
//#include "walker.hpp"

/* Functions */
bool fileExists(string &file);

#endif
